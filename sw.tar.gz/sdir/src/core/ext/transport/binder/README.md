# Binder transport for cross process IPC on Android

Under construction.

This transport implements
[BinderChannel for native cross-process communication on Android](https://github.com/grpc/proposal/blob/master/L73-java-binderchannel.md)
